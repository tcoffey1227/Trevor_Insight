﻿using System.Web.UI;

namespace ImageLibraryInSight.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}