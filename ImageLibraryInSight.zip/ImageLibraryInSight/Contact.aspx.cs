﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;

namespace ImageLibraryInSight
{
    public partial class Contact : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Page.Title = "Thomas Coffey";
            CommentsTB.Attributes.Add("onkeyup", "CountChars(255," + CommentsTB.ClientID + ");");
        }
        protected void SendMail(object sender, EventArgs e)
        {
            if (!IsValid)
            {
                return;
            }
            else
            {

                MailMessage mail = new MailMessage();
                mail.From = new MailAddress(EmailTB.Text);
                mail.To.Add("Thomasccoffey@hotmail.com");
                mail.Subject = "Contact Us";
                mail.IsBodyHtml = true;
                mail.Body = "Name: " + NameTB.Text + "<br />";
                mail.Body += "Email: " + EmailTB.Text + "<br />";
                mail.Body += "Phone: " + PhoneTB.Text + "<br />";
                mail.Body += "Comments: " + CommentsTB.Text + "<br />";
                SmtpClient smtp = new SmtpClient();
                smtp.Host = "smtp.live.com";
                sucessPH.Visible = true;

                //            smtp.Send(mail);
                /*
                 * smtp will not work unless you have the correct information
                 */
            }
        }
        protected void Reset(object s, EventArgs e)
        {
            NameTB.Text = "";
            PhoneTB.Text = "";
            EmailTB.Text = "";
            CommentsTB.Text = "";
            sucessPH.Visible = false;
        }
    }
}