﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.IO;

namespace DataClasses
{
/*
 * This class will return data as defined by the files in the Images folder
 */
    public class ImageLibrary
    {
/*
 * lay out what the record will look like
 */
        public string p_id { get; set; }
        public string p_Url { get; set; }
        public string p_title { get; set; }
        public string p_desc { get; set; }
        public long p_size { get; set; }

        public void ImageLibary()
        {

        }
    }
    public static class ImageLibraryFactory
    {
        public static DataTable GetAllImages()
        {
/*
 * This method will return a DataTable of all the objects in the Images folder
 */
            DataTable dt = new DataTable();
            /*
             * define the table's schema
             */
            dt.Columns.Add(new DataColumn("p_id", typeof(string)));
            dt.Columns.Add(new DataColumn("p_Url", typeof(string)));
            dt.Columns.Add(new DataColumn("p_title", typeof(string)));
            dt.Columns.Add(new DataColumn("p_desc", typeof(string)));
            dt.Columns.Add(new DataColumn("p_size", typeof(long)));
            /*
             * location of the calling web application
             */
            string path = AppDomain.CurrentDomain.BaseDirectory;
            string[] files = System.IO.Directory.GetFiles(path + "\\Images" + "\\", "*.jpg");
/*
 * now that we have the list of files we can populate the datatable
 */
            foreach (string s in files)
            {
                System.IO.FileInfo fi = null;
                try
                {
                    fi = new System.IO.FileInfo(s);
                }
                catch (System.IO.FileNotFoundException e)
                {
                    continue;
                }
                    DataRow dr = dt.NewRow();
                    dr["p_id"] = fi.Name;
                    dr["p_desc"] = "This is a picture named " + fi.Name;
                    dr["p_Url"] = "/Images/" + fi.Name;
                    dr["p_title"] = "Title for " + fi.Name;
                    dr["p_size"] = fi.Length;
                    dt.Rows.Add(dr);
            }
            return dt;
        }
        public static DataTable searchTitle(string _s)
        {
/*
 * this method will first get the list of all items and then filter the 
 * datatable on the title field looking for the value of _s
 * and returns a new datatable
 */
            DataTable IMDT = ImageLibraryFactory.GetAllImages();
            string _where = "p_title like '%" + _s + "%'";
            DataTable _newDataTable = IMDT.Select(_where).CopyToDataTable();
            return _newDataTable;
        }
        public static ImageLibrary getOne(string _s)
        {
/*
 * This method will take the ID of the image and returns the 
 * one record that matches this record
 * if no record is found that matches I just return the first
 * record in the set
 */
            ImageLibrary IML = new ImageLibrary();
            DataTable IMDT = ImageLibraryFactory.GetAllImages();
            string _where = "";
            if (_s != null)
            {
                _where = "p_id = '" + _s + "'";
            }
            DataTable _newDataTable = IMDT.Select(_where).CopyToDataTable();
            if (_newDataTable.Rows.Count > 0)
            {
                IML = getOneImageLibrary(_newDataTable);
            }
            else
            {
                IML = getOneImageLibrary(IMDT);
            }
            return IML;

        }
        private static ImageLibrary getOneImageLibrary(DataTable _dt)
        {
/*
 * This method just returns the first record in the datatable passed in 
 * but returns it in the say type of object we are definining ImageLibrary
 */
            ImageLibrary ret_iml = new ImageLibrary();
            ret_iml.p_id = _dt.Rows[0]["p_id"].ToString();
            ret_iml.p_desc = _dt.Rows[0]["p_desc"].ToString();
            ret_iml.p_title = _dt.Rows[0]["p_title"].ToString();
            ret_iml.p_Url = _dt.Rows[0]["p_Url"].ToString();
            ret_iml.p_size = (long)(_dt.Rows[0]["p_size"]);
            return ret_iml;
        }
    }
}
