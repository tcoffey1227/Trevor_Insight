﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Text.RegularExpressions;
using DataClasses;

namespace ImageLibraryInSight
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GetData();
            }
        }

        public void GetData()
        {
            /************************************************************
             * This method will create a DataTable with four columns
             *   1)  p_id       int
             *   2)  p_Url      string
             *   3)  p_title    string  since I did not set these I am going to use the file name
             *   4)  p_size     int
             ************************************************************/
            DataTable IMDT;
            if (txtSearch.Text == "")
            {
               IMDT = ImageLibraryFactory.GetAllImages();
            }
            else
            {
               IMDT = ImageLibraryFactory.searchTitle(txtSearch.Text);
            }

            GridView1.DataSource = IMDT;
            GridView1.DataBind();
            ViewState["DataSource"] = IMDT;
        }
        protected void grdData_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GridView1.PageIndex = e.NewPageIndex;
            GetData();
        }
        protected void GridView1_Sorting(object sender, GridViewSortEventArgs e)
        {
            DataTable dataTable = (DataTable)ViewState["DataSource"];

            if (dataTable != null)
            {
                DataView dataView = new DataView(dataTable);
                if ((string)ViewState["SortDir"] == "ASC" || String.IsNullOrEmpty((string)ViewState["SortDir"]))
                {
                    dataView.Sort = e.SortExpression + " ASC";
                    ViewState["SortDir"] = "DESC";
                }
                else if ((string)ViewState["SortDir"] == "DESC")
                {
                    dataView.Sort = e.SortExpression + " DESC";
                    ViewState["SortDir"] = "ASC";
                }

                GridView1.DataSource = dataView;
                GridView1.DataBind();
            }
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtSearch.Text = "";
            GetData();
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            GetData();
        }

    }
}