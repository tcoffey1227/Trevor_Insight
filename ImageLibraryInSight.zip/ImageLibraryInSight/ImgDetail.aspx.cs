﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DataClasses;
using System.Data;

namespace ImageLibraryInSight
{
    public partial class ImgDetail : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            getImageDetail();
        }
        private void getImageDetail()
        {
            string fid = Request.QueryString["ImID"];
             ImageLibrary IML = ImageLibraryFactory.getOne(fid);
            lbTitle.Text = IML.p_title;
            lbDesc.Text = IML.p_desc;
            lbSize.Text = (IML.p_size).ToString();
            Image1.ImageUrl = IML.p_Url;
        }
    }
}