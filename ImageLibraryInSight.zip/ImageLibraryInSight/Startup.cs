﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(ImageLibraryInSight.Startup))]
namespace ImageLibraryInSight
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
